use std::io;

fn main(){
    println!("Rust for Beginners - $15_000");
    let mut r = $15_000
    let mut rb = 
    println!("Ai Basics - $12_500");
    let mut a = $12_500
    println!("Data Structures in Rust 20_000");
    let mut d = $20_000
    println!("Networking Essentials 18_000");
    let mut n = $18_000

    let mut t = r + a + d + n 
    if t > 3,
    let 
}